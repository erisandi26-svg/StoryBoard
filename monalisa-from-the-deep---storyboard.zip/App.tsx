import React from 'react';
import { SCRIPT_DATA } from './constants';
import SceneCard from './components/SceneCard';
import { Film, Anchor, Info } from 'lucide-react';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-deep-900 text-slate-200 font-sans selection:bg-gold-500 selection:text-deep-900 pb-20">
      {/* Hero Header */}
      <header className="relative h-[40vh] md:h-[50vh] flex flex-col items-center justify-center overflow-hidden border-b border-gold-500/30">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/1920/1080?grayscale&blur=2')] bg-cover bg-center opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-deep-900/10 via-deep-900/60 to-deep-900"></div>
        
        <div className="relative z-10 text-center px-4 animate-in slide-in-from-bottom-10 fade-in duration-1000">
          <div className="flex justify-center mb-4">
            <Anchor className="text-gold-500 w-12 h-12 md:w-16 md:h-16 animate-bounce duration-[3000ms]" />
          </div>
          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 font-bold tracking-widest mb-4 drop-shadow-lg">
            MONALISA
          </h1>
          <h2 className="font-serif text-xl md:text-3xl text-gold-400 tracking-[0.3em] mb-8">
            FROM THE DEEP
          </h2>
          <div className="flex items-center justify-center gap-4 text-xs md:text-sm text-gray-400 font-mono border-t border-b border-gray-700 py-3 max-w-2xl mx-auto">
            <span>DRAMA</span>
            <span className="text-gold-500">•</span>
            <span>HISTORICAL</span>
            <span className="text-gold-500">•</span>
            <span>ROMANCE</span>
            <span className="text-gold-500">•</span>
            <span>8–10 MIN</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 md:px-6 -mt-10 relative z-20">
        <div className="max-w-5xl mx-auto">
          
          <div className="bg-deep-800/50 backdrop-blur-sm p-6 rounded-lg border border-deep-700 mb-10 flex items-start gap-4 shadow-xl">
             <Film className="w-6 h-6 text-gold-500 flex-shrink-0 mt-1" />
             <div>
               <h3 className="text-lg font-serif text-white mb-2">Logline</h3>
               <p className="text-gray-300 leading-relaxed italic">
                 "Cinta sejati tidak tenggelam." — Kisah cinta abadi antara Eleanor dan William di tengah tragedi karamnya SS Central America, terungkap kembali ratusan tahun kemudian melalui sebuah foto yang selamat dari dasar samudra.
               </p>
             </div>
          </div>

          <div className="space-y-4">
            {SCRIPT_DATA.map((scene) => (
              <SceneCard key={scene.id} scene={scene} />
            ))}
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-deep-700 bg-deep-900 pt-10 pb-10 text-center">
        <div className="flex items-center justify-center gap-2 mb-4 text-gold-500">
          <Anchor className="w-5 h-5" />
        </div>
        <p className="text-gray-500 font-serif text-sm">
          A Short Film Script Presentation
        </p>
        <p className="text-deep-700 text-xs mt-2 font-mono">
          Powered by Gemini 2.5 • React • Tailwind
        </p>
        <div className="mt-8 max-w-md mx-auto bg-deep-800/50 p-4 rounded text-xs text-gray-500 flex items-start gap-2 text-left">
            <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <p>
                Klik tombol "Visualisasikan Adegan" pada setiap kartu untuk menghasilkan ilustrasi storyboard menggunakan AI Generatif. Pastikan API Key telah terkonfigurasi.
            </p>
        </div>
      </footer>
    </div>
  );
};

export default App;