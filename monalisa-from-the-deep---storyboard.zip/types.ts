export interface Scene {
  id: number;
  title: string;
  slugline: string; // EXT. LOCATION - TIME
  description: string;
  dialogue?: Array<{
    character: string;
    text: string;
    parenthetical?: string;
  }>;
  visualPromptEn: string; // English prompt for the AI
  visualDescriptionId: string; // Indonesian description for UI
}

export interface GeneratedImage {
  sceneId: number;
  data: string; // Base64
  isLoading: boolean;
  error?: string;
}
