import { Scene } from './types';

export const SCRIPT_DATA: Scene[] = [
  {
    id: 1,
    title: "OPENING – THE DISCOVERY",
    slugline: "EXT. LAUT ATLANTIK – SIANG",
    description: "Shot drone bergerak menyapu permukaan laut luas. Cut ke kapal penelitian modern tengah menurunkan robot penyelam ke kedalaman. Monitor memperlihatkan bangkai kapal tua—SS CENTRAL AMERICA, remuk oleh waktu.",
    dialogue: [
      {
        character: "NARATOR (V.O.)",
        text: "Laut adalah penjaga rahasia. Di dasarnya terkubur kisah cinta, pengorbanan, dan keberanian… menunggu untuk ditemukan kembali."
      }
    ],
    visualPromptEn: "Cinematic wide drone shot of the vast Atlantic Ocean, cutting to a modern research ship lowering a high-tech yellow ROV submersible into deep blue water. 8k resolution, photorealistic, oceanic atmosphere.",
    visualDescriptionId: "Drone menyapu laut, kapal peneliti menurunkan robot ROV."
  },
  {
    id: 2,
    title: "FLASHBACK – AWAL KISAH",
    slugline: "EXT. PELABUHAN NEW YORK – 1857 – SORE",
    description: "Adegan sunyi penuh cahaya keemasan. ELEANOR dan WILLIAM berdiri di dermaga, saling menggenggam tangan. Cut ke foto daguerreotype mereka diambil oleh fotografer keliling.",
    dialogue: [
      {
        character: "WILLIAM",
        text: "Dua tahun aku bekerja keras di California. Tapi emas tak pernah berarti apa pun… dibandingkan dirimu."
      },
      {
        character: "ELEANOR",
        text: "Kita akan hidup sederhana, William. Itu sudah cukup."
      }
    ],
    visualPromptEn: "1857 New York Harbor at golden hour sunset. A handsome man in vintage 19th-century suit holding hands with a beautiful woman in a Victorian dress on a wooden dock. Romantic, warm lighting, cinematic historical drama style.",
    visualDescriptionId: "Eleanor & William di dermaga, senja keemasan, pakaian vintage."
  },
  {
    id: 3,
    title: "BADAI",
    slugline: "INT. SS CENTRAL AMERICA – MALAM",
    description: "Badai menghantam keras. Lampu bergoyang. Orang-orang berteriak. Air mulai membanjiri kabin. Gelombang besar menghancurkan palka atas.",
    dialogue: [
      {
        character: "WILLIAM",
        parenthetical: "(menarik Eleanor erat)",
        text: "Jika hanya satu dari kita yang bisa bertahan—itu harus kau."
      },
      {
        character: "ELEANOR",
        text: "Tidak. Kita bertahan bersama. Seperti janji kita."
      }
    ],
    visualPromptEn: "Inside a sinking 19th-century steamship cabin during a violent storm. Dark, chaotic, water rushing in, lanterns swinging wildly. A man protecting a woman. Dramatic lighting, fear, cinematic action shot.",
    visualDescriptionId: "Badai di dek kapal, ombak tinggi, cahaya kilat, kapal miring."
  },
  {
    id: 4,
    title: "PENGORBANAN",
    slugline: "EXT. DEK KAPAL – MALAM",
    description: "Para awak mengarahkan penumpang ke sekoci. William memaksa Eleanor masuk. Ia menyelipkan foto daguerreotype ke tangan Eleanor. Sekoci turun perlahan.",
    dialogue: [
      {
        character: "WILLIAM",
        text: "Jika dunia menemukan wajahmu suatu hari… mereka akan tahu cinta itu nyata."
      }
    ],
    visualPromptEn: "Night time, stormy sea. A man on a sinking ship deck saying goodbye to a woman in a lowering lifeboat. Rain, emotional, cinematic lighting, tragedy, 1857 historical setting.",
    visualDescriptionId: "Perpisahan di sekoci, tangan saling melepaskan, air mata."
  },
  {
    id: 5,
    title: "KEBANGKITAN DARI DASAR LAUT",
    slugline: "INT. LAB KAPAL PENELITI – HARI",
    description: "Operator ROV mengangkat sebuah kotak logam kecil berkarat. Saat kotak dibuka—muncul foto daguerreotype Eleanor yang masih utuh. Semua terdiam.",
    dialogue: [
      {
        character: "PENELITI",
        text: "Wajah ini… dia melihat melampaui waktu."
      }
    ],
    visualPromptEn: "Close up of a rusted metal box opened on a modern laboratory table. Inside is a perfectly preserved 1850s daguerreotype photograph of a woman. Scientific lighting, mystery, discovery.",
    visualDescriptionId: "ROV menemukan kotak foto di dasar laut, pemandangan bawah laut sunyi."
  },
  {
    id: 6,
    title: "CLOSING",
    slugline: "EXT. TEPI LAUT – SENJA",
    description: "Adegan simbolis: seorang perempuan muda membawa bunga putih, meletakkannya di tepi ombak. Fade out to title.",
    dialogue: [
      {
        character: "NARATOR (V.O.)",
        text: "Cinta sejati tidak tenggelam. Ia menunggu ditemukan… oleh mereka yang percaya."
      }
    ],
    visualPromptEn: "A young woman standing at the edge of the ocean at twilight, placing white flowers into the waves. Melancholic, peaceful, cinematic wide shot, beautiful sunset reflections on water.",
    visualDescriptionId: "Wanita meletakkan bunga di laut, senja, simbolis."
  }
];