import React, { useState } from 'react';
import { Scene } from '../types';
import { generateSceneImage } from '../services/geminiService';
import { Camera, Clapperboard, Loader2, RefreshCw, AlertCircle } from 'lucide-react';

interface SceneCardProps {
  scene: Scene;
}

const SceneCard: React.FC<SceneCardProps> = ({ scene }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await generateSceneImage(scene.visualPromptEn);
      setImageUrl(result);
    } catch (err) {
      setError("Gagal menghasilkan gambar. Silakan coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-deep-800 border-l-4 border-gold-400 rounded-r-lg shadow-xl mb-12 overflow-hidden transition-all duration-300 hover:shadow-2xl hover:bg-deep-800/80">
      {/* Script Header */}
      <div className="bg-deep-900/50 p-4 border-b border-deep-700 flex justify-between items-center">
        <div>
          <h3 className="text-gold-400 font-serif font-bold tracking-widest text-lg md:text-xl">
            SCENE {scene.id}: {scene.title}
          </h3>
          <p className="text-gray-400 font-mono text-sm uppercase tracking-wider mt-1">
            {scene.slugline}
          </p>
        </div>
        <Clapperboard className="text-deep-700 w-8 h-8 opacity-50" />
      </div>

      <div className="flex flex-col md:flex-row">
        {/* Script Content */}
        <div className="p-6 md:w-3/5 font-mono text-gray-300 leading-relaxed space-y-6">
          <p className="whitespace-pre-wrap">{scene.description}</p>
          
          {scene.dialogue && scene.dialogue.length > 0 && (
            <div className="space-y-4 pl-4 md:pl-8 border-l border-deep-700/50">
              {scene.dialogue.map((line, idx) => (
                <div key={idx} className="max-w-md mx-auto md:mx-0">
                  <div className="text-center md:text-left mb-1">
                    <span className="text-gold-500 font-bold uppercase tracking-wide">
                      {line.character}
                    </span>
                    {line.parenthetical && (
                      <span className="text-gray-500 text-sm italic block md:inline md:ml-2">
                        {line.parenthetical}
                      </span>
                    )}
                  </div>
                  <p className="text-center md:text-left text-white">
                    {line.text}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Visual Board */}
        <div className="md:w-2/5 bg-black/40 p-4 flex flex-col justify-center items-center border-t md:border-t-0 md:border-l border-deep-700 min-h-[300px]">
          {imageUrl ? (
            <div className="relative group w-full h-full">
              <img 
                src={imageUrl} 
                alt={`Scene ${scene.id} visualization`} 
                className="w-full h-full object-cover rounded shadow-lg animate-in fade-in duration-700"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <button
                  onClick={handleGenerate}
                  className="bg-gold-500 hover:bg-gold-400 text-deep-900 font-bold py-2 px-4 rounded flex items-center gap-2 transform hover:scale-105 transition-all"
                >
                  <RefreshCw className="w-4 h-4" /> Regenerate
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center p-6 w-full flex flex-col items-center justify-center h-full">
              <div className="border-2 border-dashed border-deep-700 rounded-lg p-8 w-full h-full flex flex-col items-center justify-center bg-deep-900/20">
                {loading ? (
                  <div className="flex flex-col items-center space-y-4">
                    <Loader2 className="w-10 h-10 text-gold-400 animate-spin" />
                    <p className="text-gold-400 font-serif animate-pulse">Memvisualisasikan...</p>
                  </div>
                ) : (
                  <>
                    <Camera className="w-12 h-12 text-gray-600 mb-4" />
                    <p className="text-gray-400 text-sm italic mb-6 text-center max-w-[200px]">
                      "{scene.visualDescriptionId}"
                    </p>
                    <button
                      onClick={handleGenerate}
                      disabled={loading}
                      className="bg-deep-700 hover:bg-gold-500 hover:text-deep-900 text-gold-400 border border-gold-500/30 transition-all duration-300 font-sans font-semibold py-2 px-6 rounded-full flex items-center gap-2 shadow-lg hover:shadow-gold-500/20"
                    >
                      <Camera className="w-4 h-4" />
                      Visualisasikan Adegan
                    </button>
                    {error && (
                      <div className="mt-4 flex items-center gap-2 text-red-400 text-xs bg-red-900/20 p-2 rounded">
                        <AlertCircle className="w-4 h-4" />
                        {error}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SceneCard;